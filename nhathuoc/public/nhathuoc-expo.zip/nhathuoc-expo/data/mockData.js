export const initialData = {
  vai_tro: [
    { id: 1, ten_vai_tro: 'khach_hang' },
    { id: 2, ten_vai_tro: 'bac_si' },
    { id: 3, ten_vai_tro: 'nv_quan_ly' },
    { id: 4, ten_vai_tro: 'duoc_si' },
    { id: 5, ten_vai_tro: 'admin' },
  ],
  tai_khoan: [
    { id: 1, ten_dang_nhap: 'khachhang1', mat_khau: '123456', id_vai_tro: 1, trang_thai: 1, ngay_tao: '2026-09-20 08:00:00' },
    { id: 2, ten_dang_nhap: 'bacsi1', mat_khau: '123456', id_vai_tro: 2, trang_thai: 1, ngay_tao: '2026-09-20 08:00:00' },
    { id: 3, ten_dang_nhap: 'nhanvien1', mat_khau: '123456', id_vai_tro: 3, trang_thai: 1, ngay_tao: '2026-09-20 08:00:00' },
    { id: 4, ten_dang_nhap: 'duocsi1', mat_khau: '123456', id_vai_tro: 4, trang_thai: 1, ngay_tao: '2026-09-20 08:00:00' },
    { id: 5, ten_dang_nhap: 'admin1', mat_khau: '123456', id_vai_tro: 5, trang_thai: 1, ngay_tao: '2026-09-20 08:00:00' },
  ],
  khach_hang: [
    { id: 1, id_tai_khoan: 1, ho_ten: 'Nguyễn Văn Khách', so_dien_thoai: '0901234567', email: 'khachhang1@gmail.com', dia_chi: '123 Lê Lợi, Quận 1, TP.HCM', ngay_sinh: '1995-05-15' },
    { id: 2, id_tai_khoan: 5, ho_ten: 'Trần Thị Mai', so_dien_thoai: '0987654321', email: 'mai.tran@gmail.com', dia_chi: '456 Hai Bà Trưng, Quận 3, TP.HCM', ngay_sinh: '1992-08-20' },
  ],
  bac_si: [
    { id: 1, id_tai_khoan: 2, ho_ten: 'Trần Thị Bác Sĩ', chuyen_khoa: 'Nội tổng hợp', so_dien_thoai: '0912345678', so_chung_chi_hanh_nghe: 'CCHN-00981' },
    { id: 2, id_tai_khoan: 2, ho_ten: 'Vũ Minh Quân', chuyen_khoa: 'Tai Mũi Họng', so_dien_thoai: '0918889999', so_chung_chi_hanh_nghe: 'CCHN-01452' },
  ],
  nhan_vien: [
    { id: 1, id_tai_khoan: 3, ho_ten: 'Lê Quản Lý', so_dien_thoai: '0923456789', email: 'quanly1@nhathuoc.com' },
    { id: 2, id_tai_khoan: 4, ho_ten: 'Phạm Thị Dược Sĩ', so_dien_thoai: '0934567890', email: 'duocsi1@nhathuoc.com' },
  ],
  nha_cung_cap: [
    { id: 1, ten_nha_cung_cap: 'Công ty Dược Hậu Giang', ma_so_thue: '1800156801', so_dien_thoai: '02923891433', email: 'dhg@dhgpharma.com.vn', dia_chi: '288 Bis Nguyễn Văn Cừ, Cần Thơ', nguoi_lien_he: 'Nguyễn Văn A', trang_thai: 1 },
    { id: 2, ten_nha_cung_cap: 'Công ty Cổ phần Traphaco', ma_so_thue: '0100108656', so_dien_thoai: '02436815151', email: 'info@traphaco.com.vn', dia_chi: '75 Yên Ninh, Ba Đình, Hà Nội', nguoi_lien_he: 'Trần Thị B', trang_thai: 1 },
    { id: 3, ten_nha_cung_cap: 'Sanofi Việt Nam', ma_so_thue: '0300812345', so_dien_thoai: '02838298526', email: 'contact@sanofi.com', dia_chi: '10 Hàm Nghi, Quận 1, TP.HCM', nguoi_lien_he: 'Lê Văn C', trang_thai: 1 },
  ],
  danh_muc_thuoc: [
    { id: 1, ten_danh_muc: 'Thuốc giảm đau, hạ sốt', mo_ta: 'Các loại thuốc giúp giảm triệu chứng đau và hạ sốt an toàn' },
    { id: 2, ten_danh_muc: 'Thuốc kháng sinh', mo_ta: 'Thuốc điều trị các bệnh nhiễm khuẩn (yêu cầu đơn bác sĩ)' },
    { id: 3, ten_danh_muc: 'Thực phẩm chức năng', mo_ta: 'Hỗ trợ bồi bổ sức khỏe, tăng sức đề kháng' },
    { id: 4, ten_danh_muc: 'Thuốc tiêu hóa', mo_ta: 'Hỗ trợ điều trị tiêu chảy, rối loạn tiêu hóa và men vi sinh' },
    { id: 5, ten_danh_muc: 'Vitamin & Khoáng chất', mo_ta: 'Bổ sung vi chất thiết yếu cho cơ thể mỗi ngày' },
  ],
  thuoc: [
    { id: 1, ma_sku: 'SKU001', ten_thuoc: 'Paracetamol 500mg', id_danh_muc: 1, id_nha_cung_cap: 1, loai_ke_don: 'khong_ke_don', so_dang_ky: 'VD-54321-18', don_vi_tinh: 'Hộp', gia_ban: 35000, so_luong_ton: 150, han_su_dung: '2026-12-31', trang_thai: 1 },
    { id: 2, ma_sku: 'SKU002', ten_thuoc: 'Amoxicillin 500mg', id_danh_muc: 2, id_nha_cung_cap: 1, loai_ke_don: 'ke_don', so_dang_ky: 'VD-12345-19', don_vi_tinh: 'Vỉ', gia_ban: 45000, so_luong_ton: 200, han_su_dung: '2027-06-30', trang_thai: 1 },
    { id: 3, ma_sku: 'SKU003', ten_thuoc: 'Boganic Bổ Gan', id_danh_muc: 3, id_nha_cung_cap: 2, loai_ke_don: 'khong_ke_don', so_dang_ky: 'VD-33445-20', don_vi_tinh: 'Hộp', gia_ban: 95000, so_luong_ton: 14, han_su_dung: '2026-10-15', trang_thai: 1 },
    { id: 4, ma_sku: 'SKU004', ten_thuoc: 'Berberin 100mg', id_danh_muc: 4, id_nha_cung_cap: 2, loai_ke_don: 'khong_ke_don', so_dang_ky: 'VD-11223-21', don_vi_tinh: 'Lọ', gia_ban: 25000, so_luong_ton: 120, han_su_dung: '2027-01-20', trang_thai: 1 },
    { id: 5, ma_sku: 'SKU005', ten_thuoc: 'Vitamin C 500mg Sủi', id_danh_muc: 5, id_nha_cung_cap: 1, loai_ke_don: 'khong_ke_don', so_dang_ky: 'VD-99887-22', don_vi_tinh: 'Tuýp', gia_ban: 42000, so_luong_ton: 80, han_su_dung: '2026-11-30', trang_thai: 1 },
    { id: 6, ma_sku: 'SKU006', ten_thuoc: 'Panadol Extra Đỏ', id_danh_muc: 1, id_nha_cung_cap: 3, loai_ke_don: 'khong_ke_don', so_dang_ky: 'VN-18823-14', don_vi_tinh: 'Hộp', gia_ban: 195000, so_luong_ton: 75, han_su_dung: '2027-05-15', trang_thai: 1 },
  ],
  mo_ta_thuoc: [
    {
      id: 1, id_thuoc: 1, thuong_hieu: 'DHG Pharma', dang_bao_che: 'Viên nén', quy_cach_dong_goi: 'Hộp 10 vỉ x 10 viên',
      ham_luong: '500mg', thanh_phan: 'Paracetamol',
      cong_dung: 'Giảm đau từ nhẹ đến vừa, hạ sốt nhanh chóng trong các trường hợp cảm cúm, đau đầu, đau răng.',
      doi_tuong_su_dung: 'Người lớn và trẻ em trên 12 tuổi',
      huong_dan_su_dung: 'Uống với nhiều nước sau bữa ăn.',
      lieu_dung_khuyen_cao: 'Người lớn: 1-2 viên/lần, cách nhau 4-6 giờ, tối đa 8 viên/ngày.',
      bao_quan: 'Nơi khô ráo, dưới 30°C, tránh ánh sáng trực tiếp.',
      canh_bao: 'Không dùng quá liều quy định. Thận trọng với người có tiền sử suy gan hoặc suy thận nặng.',
    },
    {
      id: 2, id_thuoc: 2, thuong_hieu: 'DHG Pharma', dang_bao_che: 'Viên nang', quy_cach_dong_goi: 'Hộp 10 vỉ x 10 viên',
      ham_luong: '500mg', thanh_phan: 'Amoxicillin trihydrat',
      cong_dung: 'Điều trị các bệnh nhiễm khuẩn đường hô hấp trên và dưới, nhiễm khuẩn tiết niệu, tai mũi họng.',
      doi_tuong_su_dung: 'Theo chỉ định nghiêm ngặt của bác sĩ',
      huong_dan_su_dung: 'Uống theo đúng liều lượng và đủ số ngày bác sĩ đã kê đơn.',
      lieu_dung_khuyen_cao: 'Người lớn: 1 viên/lần, ngày 2-3 lần sau ăn, liên tục 7-10 ngày.',
      bao_quan: 'Nơi khô mát, tránh ánh sáng.',
      canh_bao: 'Chỉ sử dụng khi có đơn của bác sĩ. Ngưng thuốc và báo ngay cho cơ sở y tế nếu xuất hiện dị ứng.',
    },
    {
      id: 3, id_thuoc: 3, thuong_hieu: 'Traphaco', dang_bao_che: 'Viên bao đường', quy_cach_dong_goi: 'Hộp 5 vỉ x 20 viên',
      ham_luong: 'Hỗn hợp cao dược liệu', thanh_phan: 'Cao Actisô, Cao Biển súc, Cao Bìm bìm',
      cong_dung: 'Bổ gan, thanh nhiệt giải độc, tăng cường chức năng gan trong trường hợp viêm gan, men gan cao, dị ứng mẩn ngứa.',
      doi_tuong_su_dung: 'Người lớn và trẻ em trên 8 tuổi',
      huong_dan_su_dung: 'Uống trước hoặc sau ăn với nước ấm.',
      lieu_dung_khuyen_cao: 'Người lớn: 2-4 viên/lần, ngày 3 lần.',
      bao_quan: 'Nơi khô ráo, thoáng mát, nhiệt độ dưới 30°C.',
      canh_bao: 'Không dùng cho phụ nữ có thai mà chưa hỏi ý kiến chuyên môn.',
    },
    {
      id: 4, id_thuoc: 4, thuong_hieu: 'Traphaco', dang_bao_che: 'Viên nén', quy_cach_dong_goi: 'Lọ 100 viên',
      ham_luong: '100mg', thanh_phan: 'Berberin clorid',
      cong_dung: 'Hỗ trợ điều trị lỵ trực trùng, hội chứng lỵ, viêm ruột, tiêu chảy do nhiễm khuẩn.',
      doi_tuong_su_dung: 'Người lớn và trẻ em trên 2 tuổi',
      huong_dan_su_dung: 'Uống một lần vào buổi sáng hoặc chia làm 2 lần trong ngày.',
      lieu_dung_khuyen_cao: 'Người lớn: 2-4 viên/lần, ngày 2 lần.',
      bao_quan: 'Để nơi khô ráo, tránh ánh sáng.',
      canh_bao: 'Chống chỉ định cho phụ nữ có thai.',
    },
    {
      id: 5, id_thuoc: 5, thuong_hieu: 'DHG Pharma', dang_bao_che: 'Viên sủi bọt', quy_cach_dong_goi: 'Tuýp 10 viên',
      ham_luong: '500mg', thanh_phan: 'Acid ascorbic (Vitamin C)',
      cong_dung: 'Bổ sung Vitamin C, tăng cường sức đề kháng cho cơ thể khi ốm hoặc thời tiết thay đổi.',
      doi_tuong_su_dung: 'Người lớn và trẻ em trên 6 tuổi',
      huong_dan_su_dung: 'Hòa tan 1 viên trong khoảng 200ml nước đun sôi để nguội.',
      lieu_dung_khuyen_cao: '1 viên/ngày, nên uống vào buổi sáng hoặc trưa sau ăn.',
      bao_quan: 'Đậy kín nắp tuýp, tránh ẩm.',
      canh_bao: 'Không uống vào buổi tối trước khi đi ngủ.',
    },
    {
      id: 6, id_thuoc: 6, thuong_hieu: 'GSK', dang_bao_che: 'Viên nén dài', quy_cach_dong_goi: 'Hộp 15 vỉ x 12 viên',
      ham_luong: '500mg Paracetamol + 65mg Caffeine', thanh_phan: 'Paracetamol, Caffeine',
      cong_dung: 'Giảm đau nhanh, hạ sốt hiệu quả đối với các cơn đau khó chịu như đau đầu, đau cơ bắp, đau răng.',
      doi_tuong_su_dung: 'Người lớn và trẻ em từ 12 tuổi trở lên',
      huong_dan_su_dung: 'Uống với nước sau bữa ăn.',
      lieu_dung_khuyen_cao: '1-2 viên mỗi 4-6 giờ khi cần, tối đa 8 viên/ngày.',
      bao_quan: 'Bảo quản ở nhiệt độ dưới 30°C.',
      canh_bao: 'Chứa caffeine, hạn chế dùng các thức uống chứa caffeine khác.',
    },
  ],
  anh_thuoc: [
    { id: 1, id_thuoc: 1, duong_dan_anh: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
    { id: 2, id_thuoc: 2, duong_dan_anh: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
    { id: 3, id_thuoc: 3, duong_dan_anh: 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
    { id: 4, id_thuoc: 4, duong_dan_anh: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
    { id: 5, id_thuoc: 5, duong_dan_anh: 'https://images.unsplash.com/photo-1576073719676-aa955fc6b889?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
    { id: 6, id_thuoc: 6, duong_dan_anh: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&auto=format&fit=crop&q=60', la_anh_chinh: 1, thu_tu: 1 },
  ],
  khuyen_mai: [
    { id: 1, ma_code: 'CHAOMUNG10', mo_ta: 'Giảm 10% cho đơn hàng đầu tiên', loai_giam: 'phan_tram', gia_tri_giam: 10, don_toi_thieu: 50000, ngay_bat_dau: '2026-01-01', ngay_ket_thuc: '2026-12-31', so_luong_toi_da: 1000 },
    { id: 2, ma_code: 'GIAM20K', mo_ta: 'Giảm ngay 20.000đ cho đơn từ 100.000đ', loai_giam: 'so_tien', gia_tri_giam: 20000, don_toi_thieu: 100000, ngay_bat_dau: '2026-01-01', ngay_ket_thuc: '2026-12-31', so_luong_toi_da: 500 },
  ],
  don_thuoc: [
    { id: 1, id_khach_hang: 1, id_bac_si: 1, ngay_ke_don: '2026-09-20', trang_thai: 'da_duyet', id_nhan_vien_duyet: 2, ngay_duyet: '2026-09-21 09:30:00', ghi_chu_duyet: 'Toa hợp lệ, đã đối chiếu với bác sĩ kê' },
    { id: 2, id_khach_hang: 2, id_bac_si: 2, ngay_ke_don: '2026-09-28', trang_thai: 'cho_duyet', id_nhan_vien_duyet: null, ngay_duyet: null, ghi_chu_duyet: null },
  ],
  chi_tiet_don_thuoc: [
    { id: 1, id_don_thuoc: 1, id_thuoc: 2, so_luong_ke: 1, lieu_dung: 'Ngày uống 3 lần, mỗi lần 1 viên sau ăn', so_ngay_dung: 7 },
    { id: 2, id_don_thuoc: 2, id_thuoc: 2, so_luong_ke: 2, lieu_dung: 'Ngày uống 2 lần, mỗi lần 1 viên', so_ngay_dung: 10 },
  ],
  don_dat_thuoc: [
    { id: 1, id_khach_hang: 1, id_don_thuoc: 1, id_khuyen_mai: 1, tong_tien: 45000, giam_gia: 4500, thanh_tien: 40500, dia_chi_giao_hang: '123 Lê Lợi, Quận 1, TP.HCM', so_dien_thoai_nhan: '0901234567', trang_thai: 'cho_xac_nhan', ngay_dat: '2026-09-21 10:15:00' },
    { id: 2, id_khach_hang: 2, id_don_thuoc: null, id_khuyen_mai: 2, tong_tien: 137000, giam_gia: 20000, thanh_tien: 117000, dia_chi_giao_hang: '456 Hai Bà Trưng, Quận 3, TP.HCM', so_dien_thoai_nhan: '0987654321', trang_thai: 'dang_giao', ngay_dat: '2026-09-29 14:20:00' },
  ],
  chi_tiet_don_dat: [
    { id: 1, id_don_dat: 1, id_thuoc: 2, so_luong: 1, don_gia: 45000 },
    { id: 2, id_don_dat: 2, id_thuoc: 3, so_luong: 1, don_gia: 95000 },
    { id: 3, id_don_dat: 2, id_thuoc: 5, so_luong: 1, don_gia: 42000 },
  ],
  lich_su_theo_doi_don: [
    { id: 1, id_don_dat: 1, trang_thai_cap_nhat: 'cho_xac_nhan', ghi_chu: 'Khách hàng vừa đặt đơn mới trên ứng dụng', thoi_gian_cap_nhat: '2026-09-21 10:15:00' },
    { id: 2, id_don_dat: 2, trang_thai_cap_nhat: 'cho_xac_nhan', ghi_chu: 'Đơn hàng đã được ghi nhận', thoi_gian_cap_nhat: '2026-09-29 14:20:00' },
    { id: 3, id_don_dat: 2, trang_thai_cap_nhat: 'dang_giao', ghi_chu: 'Đã bàn giao đơn hàng cho shipper', thoi_gian_cap_nhat: '2026-09-29 15:30:00' },
  ],
  thanh_toan: [
    { id: 1, id_don_dat: 1, phuong_thuc: 'vi_dien_tu', ma_giao_dich: 'MOMO20260920001', so_tien: 40500, trang_thai: 'da_thanh_toan', thoi_gian_thanh_toan: '2026-09-21 10:16:00' },
    { id: 2, id_don_dat: 2, phuong_thuc: 'tien_mat', ma_giao_dich: 'COD20260929002', so_tien: 117000, trang_thai: 'cho_thanh_toan', thoi_gian_thanh_toan: null },
  ],
  hoa_don: [
    { id: 1, id_don_dat: 1, so_hoa_don: 'HD2026000001', tong_tien_truoc_thue: 40500, thue_vat: 0, tong_tien_sau_thue: 40500, ngay_lap: '2026-09-21 10:16:00' },
    { id: 2, id_don_dat: 2, so_hoa_don: 'HD2026000002', tong_tien_truoc_thue: 117000, thue_vat: 0, tong_tien_sau_thue: 117000, ngay_lap: '2026-09-29 14:21:00' },
  ],
  danh_gia: [
    { id: 1, id_khach_hang: 1, id_thuoc: 1, so_sao: 5, noi_dung: 'Thuốc tác dụng rất nhanh, giá hợp lý, giao hàng chuẩn.', ngay_danh_gia: '2026-09-22' },
    { id: 2, id_khach_hang: 2, id_thuoc: 3, so_sao: 5, noi_dung: 'Boganic uống mát gan, giảm mụn nhọt rõ rệt sau 2 tuần.', ngay_danh_gia: '2026-09-25' },
    { id: 3, id_khach_hang: 1, id_thuoc: 5, so_sao: 4, noi_dung: 'Viên sủi vị cam dễ uống, tăng đề kháng rất tốt.', ngay_danh_gia: '2026-09-26' },
  ],
  phieu_nhap_thuoc: [
    { id: 1, id_nhan_vien: 1, id_nha_cung_cap: 1, tong_tien: 5500000, ghi_chu: 'Nhập lô hàng bổ sung tháng 9', ngay_nhap: '2026-09-15' },
    { id: 2, id_nhan_vien: 2, id_nha_cung_cap: 2, tong_tien: 4200000, ghi_chu: 'Nhập thực phẩm chức năng và Berberin', ngay_nhap: '2026-09-22' },
  ],
  chi_tiet_phieu_nhap: [
    { id: 1, id_phieu_nhap: 1, id_thuoc: 1, so_luong: 100, gia_nhap: 25000, so_lo: 'L19283', han_su_dung: '2026-12-31' },
    { id: 2, id_phieu_nhap: 1, id_thuoc: 2, so_luong: 100, gia_nhap: 30000, so_lo: 'L19284', han_su_dung: '2027-06-30' },
    { id: 3, id_phieu_nhap: 2, id_thuoc: 3, so_luong: 50, gia_nhap: 70000, so_lo: 'L20441', han_su_dung: '2026-10-15' },
  ],
  lich_su_trang_thai_nhap: [
    { id: 1, id_phieu_nhap: 1, trang_thai: 'da_nhap_kho', nguoi_cap_nhat: 1, ghi_chu: 'Đã kiểm tra chất lượng và số lượng lô hàng', thoi_gian_cap_nhat: '2026-09-15 11:00:00' },
    { id: 2, id_phieu_nhap: 2, trang_thai: 'da_nhap_kho', nguoi_cap_nhat: 2, ghi_chu: 'Hàng đạt chuẩn quy cách', thoi_gian_cap_nhat: '2026-09-22 16:30:00' },
  ],
  gio_hang: [
    { id: 1, id_khach_hang: 1, id_thuoc: 3, so_luong: 1 },
  ],
  v_thuoc_ke_don: [
    { id: 2, ten_thuoc: 'Amoxicillin 500mg', so_dang_ky: 'VD-12345-19' },
  ],
  v_thuoc_sap_het_han: [
    { id: 3, ten_thuoc: 'Boganic Bổ Gan', han_su_dung: '2026-10-15', so_luong_ton: 50 },
  ],
};

export const services = [
  {
    title: 'Tư vấn sức khỏe',
    caption: 'Giải đáp cách dùng và lưu ý an toàn cùng dược sĩ.',
    icon: '💬',
  },
  {
    title: 'Đóng gói cẩn thận',
    caption: 'Sản phẩm được kiểm tra trước khi gửi đến bạn.',
    icon: '📦',
  },
  {
    title: 'Theo dõi đơn hàng',
    caption: 'Luôn nắm được tình trạng đơn từ lúc đặt đến khi nhận.',
    icon: '🕒',
  },
];

export const formatPrice = (value) => `${Number(value || 0).toLocaleString('vi-VN')} ₫`;

export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? String(dateStr) : d.toLocaleDateString('vi-VN');
  } catch {
    return String(dateStr);
  }
};

export const getOrderStatusMeta = (status) => {
  switch (status) {
    case 'cho_xac_nhan':
      return { label: 'Chờ xác nhận', color: '#eab308', bg: '#fef9c3' };
    case 'dang_giao':
      return { label: 'Đang giao', color: '#0284c7', bg: '#e0f2fe' };
    case 'hoan_thanh':
      return { label: 'Hoàn thành', color: '#16a34a', bg: '#dcfce7' };
    case 'da_huy':
      return { label: 'Đã hủy', color: '#dc2626', bg: '#fee2e2' };
    default:
      return { label: status || 'Chờ xử lý', color: '#64748b', bg: '#f1f5f9' };
  }
};
